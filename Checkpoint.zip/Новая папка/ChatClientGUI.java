import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class ChatClientGUI {
    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private String username;

    private JFrame frame = new JFrame("ChatApp");
    private JTextArea chatArea = new JTextArea(25, 60);
    private JTextField inputField = new JTextField();
    private JList<String> userList = new JList<>();
    private DefaultListModel<String> userModel = new DefaultListModel<>();

    public ChatClientGUI() {
        setupGUI();
        connectToServer();
    }

    private void setupGUI() {
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);

        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputField.addActionListener(e -> sendMessage());

        userList.setModel(userModel);
        userList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        userList.setFixedCellWidth(160);

        JScrollPane chatScroll = new JScrollPane(chatArea);
        JScrollPane usersScroll = new JScrollPane(userList);

        frame.setLayout(new BorderLayout());
        frame.add(chatScroll, BorderLayout.CENTER);
        frame.add(inputField, BorderLayout.SOUTH);
        frame.add(usersScroll, BorderLayout.EAST);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void connectToServer() {
        try {
            socket = new Socket("localhost", 1234);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));

            startMessageReader(); // Запускаем чтение сразу
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Ошибка подключения!");
            System.exit(1);
        }
    }

    private void startMessageReader() {
        new Thread(() -> {
            try {
                String msg;
                while ((msg = in.readLine()) != null) {
                    final String finalMsg = msg;
                    SwingUtilities.invokeLater(() -> {
                        if (finalMsg.startsWith("ОНЛАЙН: ")) {
                            userModel.clear();
                            String users = finalMsg.substring(8);
                            for (String u : users.split(",\\s*")) {
                                if (!u.isBlank()) userModel.addElement(u.trim());
                            }
                        } else {
                            chatArea.append(finalMsg + "\n");
                            chatArea.setCaretPosition(chatArea.getDocument().getLength());
                        }
                    });
                }
            } catch (IOException e) {
                SwingUtilities.invokeLater(() -> chatArea.append("Соединение разорвано.\n"));
            }
        }).start();
    }

    private void sendMessage() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;

        try {
            out.write(text);
            out.newLine();
            out.flush();
            inputField.setText("");
        } catch (IOException e) {
            chatArea.append("Ошибка: сообщение не отправлено.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatClientGUI::new);
    }
}